// Main entry for react-9b6yr3.onspace.build
(function() {
  'use strict';

  const app = document.getElementById('app');

  function init() {
    console.log('App initialized');
    render();
  }

  function render() {
    app.innerHTML = '<h1>Hello from react-9b6yr3.onspace.build</h1>';
  }

  document.addEventListener('DOMContentLoaded', init);
})();