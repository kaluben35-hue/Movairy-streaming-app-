import React from 'react';

const About: React.FC = () => {
  return (
    <div className="container mx-auto py-12">
      <h2 className="text-3xl font-bold mb-4">About Us</h2>
      <p className="text-slate-400">Learn more about our mission and team.</p>
    </div>
  );
};

export default About;