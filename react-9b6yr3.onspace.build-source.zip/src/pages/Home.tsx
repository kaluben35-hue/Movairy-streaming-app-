import React from 'react';

const Home: React.FC = () => {
  return (
    <main className="min-h-screen bg-slate-900 text-white">
      <section className="container mx-auto py-24 text-center">
        <h1 className="text-5xl font-bold mb-6">Welcome to react-9b6yr3.onspace.build</h1>
        <p className="text-xl text-slate-400 max-w-2xl mx-auto">
          A modern web application built with React, TypeScript, and Tailwind CSS.
        </p>
      </section>
    </main>
  );
};

export default Home;