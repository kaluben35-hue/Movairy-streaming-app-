import { useState, useCallback } from 'react';

interface AuthState {
  user: { id: string; email: string } | null;
  loading: boolean;
}

export function useAuth() {
  const [state, setState] = useState<AuthState>({ user: null, loading: false });

  const login = useCallback(async (email: string, password: string) => {
    setState(s => ({ ...s, loading: true }));
    // auth logic here
    setState(s => ({ ...s, loading: false }));
  }, []);

  const logout = useCallback(() => {
    setState({ user: null, loading: false });
  }, []);

  return { ...state, login, logout };
}